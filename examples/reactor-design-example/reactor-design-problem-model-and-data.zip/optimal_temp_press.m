temp_range = 300:1.5:400;
pres_range = 1:1.5:161;
[T, P] = meshgrid(temp_range, pres_range);
Yield = zeros(size(T));
Selectivity = zeros(size(T));

t = 0;
for T = temp_range    
    p = 0;
    t = t + 1
    for P = pres_range
        p = p + 1;        
        overall_yield = project_driver(T, P);
        Yield(p, t) = overall_yield(end);
        %Selectivity(p, t) = overall_selectivity(end);
    end
end

[T, P] = meshgrid(temp_range, pres_range);
mesh(T, P, Yield)
xlabel('T')
ylabel('P')