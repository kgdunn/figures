function d_depnt__d_indep = project(indep, depnt, param)
% Dynamic balances for the PFR
% 
%    indep: the independent ODE variable, such as time or length
%    depnt: a vector of dependent variables
%    Returns d(depnt)/d(indep) = a vector of ODEs
 
% Assign some variables for convenience of notation
FA = depnt(1);  % CO [mol/s]     = A
FB = depnt(2);  % H2 [mol/s]     = B
FC = depnt(3);  % CH3OH [mol/s]  = C
FD = depnt(4);  % H20 [mol/s]    = D
FE = depnt(5);  % CO2 [mol/s]    = E
y  = depnt(6);  % y = P/P0 [-]
T  = depnt(7);  % Temperature [K]

% Constant(s)
R = 8.314;        % [J/(mol.K)]
R_imp = 1.987;    % [cal/(mol.K)]
param.P_0;        % [Pa]
param.T_0;        % [K]
Dp = 3/1000;      % particle size [m] = 2mm
T_ref = 298;      % [K]

% Physical properties
% Heat capacities are from Felder and Rousseau and are reasonably constant over the range of 
% temperatures considered in the project
Cp_A = 28.95;   % J/mol CO
Cp_B = 28.84;   % J/mol H2
Cp_C = 42.93;   % J/mol CH3OH  61.43 J/(mol K) at 100-223�C
Cp_D = 33.46;   % J/mol H20
Cp_E = 36.11;   % J/mol CO2
mu = 7.5E-6;   % [Pa.s]  using midway between 300K and 400K of the CO2 viscosity

% Heats of formation at standard conditions [Felder]
Hf_A = -110.52*1000;   % [J/mol] CO
Hf_B = 0;              % [J/mol] H2
Hf_C = -201.2*1000;    % [J/mol] CH3OH
Hf_D = -241.83*1000;   % [J/mol] H20
Hf_E = -393.5*1000;    % [J/mol] CO2

% Algebraic equations
C_T0 = param.P_0 / (R*param.T_0);
KC_1 = 131667 * (0.001987*T)^2 * exp(30620/R_imp*(1/T - 1/298))   / 1E6;
KC_2 = 103943 * exp(9834/R_imp*(1/T - 1/298));
k1 = 0.933 * exp(2.5*(31400/R_imp)*(1/330 - 1/T))                 / 1E6    /10000;
k2 = 0.636 * exp(18000/R_imp*(1/300-1/T))                         / 1E3    /1000;
k1R = k1 / KC_1;
k2R = k2 / KC_2;

FT = FA + FB + FC + FD + FE;
CA = (param.F_T0 / param.q_0) * (FA/FT) * y * (param.T_0 / T);
CB = (param.F_T0 / param.q_0) * (FB/FT) * y * (param.T_0 / T);
CC = (param.F_T0 / param.q_0) * (FC/FT) * y * (param.T_0 / T);
CD = (param.F_T0 / param.q_0) * (FD/FT) * y * (param.T_0 / T);
CE = (param.F_T0 / param.q_0) * (FE/FT) * y * (param.T_0 / T);
%CA = C_T0 * (FA / FT) * y * (param.T_0 / T);
%CB = C_T0 * (FB / FT) * y * (param.T_0 / T);
%CC = C_T0 * (FC / FT) * y * (param.T_0 / T);
%CD = C_T0 * (FD / FT) * y * (param.T_0 / T);
%CE = C_T0 * (FE / FT) * y * (param.T_0 / T);

% Reaction rates for reaction 1: A + 2B -> C   (basis = A)
r1A = -k1 * CA * CB^2;   % [mol A formed per m^3, per second], yes, formed!
r1B = 2*r1A;
r1C = -r1A;
% Reaction rates for reaction 2: C -> A + 2B   (basis = C)
r2C = -k1R * CC;         % [mol C formed per m^3, per second]
r2A = -r2C;
r2B = -2*r2C;
% Reaction rates for reaction 3: A + D -> E + B  (basis = A)
r3A = -k2 * CA * CD;     % [mol A formed per m^3, per second]
r3D = r3A;
r3E = -r3A;
r3B = -r3A;
% Reaction rates for reaction 4: B + E -> A + D  (basis = B)
r4B = -k2R * CB * CE;    % [mol B formed per m^3, per second]
r4E = r4B;
r4A = -r4B;
r4D = -r4B;

% Isothermal and isobaric assumptions
if param.isothermal
    T = param.T_0;
    temperature_effect = 0;
else
    T_amb = 95 + 273;  % [K]
    heat_removed = param.U * param.OD/4 * (T - T_amb);   % [J/(s.m^2.K) * m^2/m^3 reactor * K] = [J/(s . m^3 reactor ]
    h_rxn_1_base = 1*Hf_C - Hf_A - 2*Hf_B;      % [J/(mol A)
    h_rxn_2_base = -h_rxn_1_base;               % [J/(mol C)
    h_rxn_3_base = Hf_B + Hf_E - Hf_A - Hf_D;   % [J/(mol A)
    h_rxn_4_base = -h_rxn_3_base;               % [J/(mol B)
    
    Delta_CP1 = 1*Cp_C - Cp_A - 2*Cp_B;         % [J/(mol A).K]
    Delta_CP2 = -Delta_CP1;                     % [J/(mol C).K]
    Delta_CP3 = Cp_B + Cp_E - Cp_A - Cp_D;      % [J/(mol A).K]
    Delta_CP4 = -Delta_CP3;                     % [J/(mol B).K]
    
    heat_rxn_1A = h_rxn_1_base + Delta_CP1*(T - T_ref);   % [J/(mol A reacted)]
    heat_rxn_2C = h_rxn_2_base + Delta_CP2*(T - T_ref);   % [J/(mol C reacted)]
    heat_rxn_3A = h_rxn_3_base + Delta_CP3*(T - T_ref);   % [J/(mol A reacted)]
    heat_rxn_4B = h_rxn_4_base + Delta_CP4*(T - T_ref);   % [J/(mol B reacted)]
    
    %[heat_rxn_1A/h_rxn_1_base heat_rxn_3A/h_rxn_3_base]
    % [mol B created per m^3, per second][J/(mol B reacted)]
    
    heat_rxn_total = (-r1A)*(-heat_rxn_1A) + r2C*heat_rxn_2C + r3A*heat_rxn_3A + r4B*heat_rxn_4B;   % [J/(m^3 reactor . s)]
    %[r1A*heat_rxn_1A  r2C*heat_rxn_2C  r3A*heat_rxn_3A  r4B*heat_rxn_4B]./heat_rxn_total

    num = (heat_rxn_total - heat_removed) / param.rho_B;    % [J/(m^3 . s)]*[m^3/kg cat] = [J / (kg cat) / s]
    den = FA*Cp_A + FB*Cp_B + FC*Cp_C + FD*Cp_D + FE*Cp_E;  % [mol/s] * [J/(mol.K)] = [J/(K.s)]
    temperature_effect = num / den;                         % [J / (kg cat) / s] / J/(K.s)] = [K / (kg cat)]
end

if param.isobaric
    y = 1;
    alpha = 0;
else
    mass_flow = param.F_T0 * param.average_MM_0;  % [mol/s  * kg/mol = kg/s]
    G = mass_flow / param.A_C;                    % [kg/s / m^2] 
    laminar = 150*(1 - param.phi) * mu / Dp;      % [Pa.s/m] = (kg/m/s^2)*s/m = kg/s/m^2]
    turbulent = 1.75 * G;                         % [kg/s/m^2]
    beta = G * (1 - param.phi) / (param.rho_gas_0 * Dp * param.phi^3) * (laminar + turbulent);   % [Pa/m]
           % [kg/s/m^2] / (kg/m^2)   * [kg/s/m^2] = [kg^2/s^2/m^4]/(kg/m^2) = kg/(s^2 . m^2) = Pa/m 
    alpha = 2 * beta / (param.A_C * param.rho_B * param.P_0);  % [1/kg]
end

% Output from this ODE function must be a COLUMN vector, with n rows
n = numel(depnt);
d_depnt__d_indep = zeros(n,1);
d_depnt__d_indep(1) = (r1A + r2A + r3A + r4A)/param.rho_B;   % [mol/(m^3.s)] * [m^3 reactor / kg] = [mol/(kg cat)/s]
d_depnt__d_indep(2) = (r1B + r2B + r3B + r4B)/param.rho_B;
d_depnt__d_indep(3) = (r1C + r2C)/param.rho_B;
d_depnt__d_indep(4) = (r3D + r4D)/param.rho_B;
d_depnt__d_indep(5) = (r3E + r4E)/param.rho_B;
d_depnt__d_indep(6) = -alpha / (2*y) * (FT/param.F_T0) * (T/param.T_0);
d_depnt__d_indep(7) = temperature_effect;