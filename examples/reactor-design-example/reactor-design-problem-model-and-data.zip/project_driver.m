
function Overall_yield = project_driver(T_0, P_0)

show_plots = false;

% Number of tubes. We will only simulate 1 tube.
% Reasonable size of a HEx is about 0.5m in diameter.
% Area of 0.5m diameter face plate = pi*0.25^2. So pi*0.25^2*(1-0.4)/A_C = 103 tubes, assuming 60% of 
% face plate area is occupied by tubes. 
% Area of 1.0m diameter face plate = pi*0.5^2. So pi*0.5^2*(1-0.4)/A_C = 400 tubes, assuming 60% of 
% face plate area is occupied by tubes. 
n_tubes = 250;

% The independent variable always requires an initial and final value:
indep_start = 0.0;   % kg
V_max = 2.0;         % m^3
ID = 0.0381;         % internal diameter of tubes [m]
phi = 0.4;           % void fraction
rho_C = 1600;        % [kg/m^3 of catalyst]
A_C = (pi*(ID/2)^2); % [m^2] cross-sectional area
indep_final = rho_C * V_max * phi / n_tubes;  % kg
tube_length = V_max / n_tubes / A_C;
 
% Algebraic initial conditions:
F_T0 = 30.0;            % mol/s
F_T0 = F_T0 / n_tubes;  % [mol/s] per tube
P_0 = 101325 * P_0;     % Pa


isothermal = true;
isobaric = true;


param.U = 631;          % Heat transfer coeff [W/(m^2.K)]
param.ID = ID;
param.OD = 4/1000;      % 4mm pipe thickness
param.F_T0 = F_T0;
param.T_0 = T_0;
param.P_0 = P_0;
param.rho_B = (1 - phi)*rho_C; % [kg/m^3 of reactor volume]
param.A_C = A_C;
param.phi = phi;
param.isothermal = isothermal;
param.isobaric = isobaric;

% Set initial condition(s): for integrating variables (dependent variables)
FA_depnt_zero = 1/5*F_T0;    % i.e. FA(W=0)
FB_depnt_zero = 7/15*F_T0;   % i.e. FB(W=0)
FC_depnt_zero = 0*F_T0;      % i.e. FC(W=0)
FD_depnt_zero = 2/15*F_T0;   % i.e. FD(W=0)
FE_depnt_zero = 1/5*F_T0;    % i.e. FE(W=0)
y_depnt_zero  = 1.0;         % i.e. y(W=0)
T_depnt_zero = T_0;          % i.e. T(W=0)

% Feed molar mass
M_A = 28.01/1000;            % [kg/mol]
M_B = 2.0158/1000;           % [kg/mol]
M_C = 32.04/1000;            % [kg/mol]
M_D = 18.0153/1000;          % [kg/mol]
M_E = 44.01/1000;            % [kg/mol]

% The average molar mass of the feed [kg/mol]
param.average_MM_0 = 1/5*M_A + 7/15*M_B + 0*M_C + 2/15*M_D + 1/5*M_E;

% Used to calculate the feed density, assuming ideal gas law applies.
param.rho_gas_0 = param.average_MM_0 * param.P_0 / (8.314 * param.T_0);

% Initial volumetric flowrate [m^3/s]
param.q_0 = F_T0 * param.average_MM_0 / param.rho_gas_0;

% Integrate the ODE(s):
options = odeset();          % Use the default options
[indep, depnt] = ode23s(@project, [indep_start, indep_final], ...
                        [FA_depnt_zero, FB_depnt_zero, FC_depnt_zero, FD_depnt_zero, ...
                         FE_depnt_zero,  y_depnt_zero,  T_depnt_zero], options, param);
FA = depnt(:,1) * n_tubes;  % CO [mol/s]     = A
FB = depnt(:,2) * n_tubes;  % H2 [mol/s]     = B
FC = depnt(:,3) * n_tubes;  % CH3OH [mol/s]  = C
FD = depnt(:,4) * n_tubes;  % H20 [mol/s]    = D
FE = depnt(:,5) * n_tubes;  % CO2 [mol/s]    = E
FA_depnt_zero = FA_depnt_zero * n_tubes;
Overall_yield = FC ./ (FA_depnt_zero - FA) * 100;                  
%Overall_selectivity = FC ./ FE;
[Overall_yield(end) max(Overall_yield)];

if show_plots
    figure
    plot(indep, Overall_yield)
    hold on
    %plot(indep, Overall_selectivity*100, 'r'); grid()
    ylabel('Yield [%]')
    legend('Yield')

    % Plot the results:
    figure;
    %plot(indep, depnt(:,1), 'b')
    grid('on')
    hold('on')
    %plot(indep, depnt(:,2), 'g')
    plot(indep, depnt(:,3), 'k')
    %plot(indep, depnt(:,4), 'r')
    %plot(indep, depnt(:,5), 'm')
    xlabel('W [kg]')
    ylabel('Molar flows [mol/s]')
    legend('F_C')
    %legend('F_A', 'F_B', 'F_C', 'F_D', 'F_E')
    
    figure;
    plot(indep, depnt(:,7), 'r')
    ylabel('Temperature')
    grid on
    figure;
    plot(indep, depnt(:,6), 'k')
    ylabel('Pressure')
    grid on
end
